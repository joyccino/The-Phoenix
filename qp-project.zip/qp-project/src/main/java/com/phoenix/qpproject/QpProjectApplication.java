package com.phoenix.qpproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QpProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(QpProjectApplication.class, args);
	}

}
