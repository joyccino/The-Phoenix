package com.phoenix.qpproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QpProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
