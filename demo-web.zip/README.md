# The Phoenix

Adversity makes a man wise, though not rich.
- Thomas Fuller
